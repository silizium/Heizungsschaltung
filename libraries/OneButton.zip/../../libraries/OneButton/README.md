Arduino OneButton Library
===

This Arduino libary is improving the usage of a singe button for input.
It shows how to use an digital input pin with a single pushbutton attached
for detecting some of the typical button press events like single clicks, double clicks and long-time pressing.
This enables you to reuse the same button for multiple functions and lowers the hardware invests.

This is also a sample for implementing simple finite-state machines by using the simple pattern above. 

You can find more detail on this library at
http://www.mathertel.de/Arduino/OneButtonLibrary.aspx
